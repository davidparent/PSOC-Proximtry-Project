/*******************************************************************************
* File Name: PRSm.h
* Version 2.10
*
* Description:
*  This file provides constants and parameter values for the PRSm
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_TCPWM_PRSm_H)
#define CY_TCPWM_PRSm_H


#include "CyLib.h"
#include "cytypes.h"
#include "cyfitter.h"


/*******************************************************************************
* Internal Type defines
*******************************************************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} PRSm_BACKUP_STRUCT;


/*******************************************************************************
* Variables
*******************************************************************************/
extern uint8  PRSm_initVar;


/***************************************
*   Conditional Compilation Parameters
****************************************/

#define PRSm_CY_TCPWM_V2                    (CYIPBLOCK_m0s8tcpwm_VERSION == 2u)
#define PRSm_CY_TCPWM_4000                  (CY_PSOC4_4000)

/* TCPWM Configuration */
#define PRSm_CONFIG                         (7lu)

/* Quad Mode */
/* Parameters */
#define PRSm_QUAD_ENCODING_MODES            (0lu)
#define PRSm_QUAD_AUTO_START                (0lu)

/* Signal modes */
#define PRSm_QUAD_INDEX_SIGNAL_MODE         (0lu)
#define PRSm_QUAD_PHIA_SIGNAL_MODE          (3lu)
#define PRSm_QUAD_PHIB_SIGNAL_MODE          (3lu)
#define PRSm_QUAD_STOP_SIGNAL_MODE          (0lu)

/* Signal present */
#define PRSm_QUAD_INDEX_SIGNAL_PRESENT      (0lu)
#define PRSm_QUAD_STOP_SIGNAL_PRESENT       (0lu)

/* Interrupt Mask */
#define PRSm_QUAD_INTERRUPT_MASK            (1lu)

/* Timer/Counter Mode */
/* Parameters */
#define PRSm_TC_RUN_MODE                    (0lu)
#define PRSm_TC_COUNTER_MODE                (0lu)
#define PRSm_TC_COMP_CAP_MODE               (2lu)
#define PRSm_TC_PRESCALER                   (0lu)

/* Signal modes */
#define PRSm_TC_RELOAD_SIGNAL_MODE          (0lu)
#define PRSm_TC_COUNT_SIGNAL_MODE           (3lu)
#define PRSm_TC_START_SIGNAL_MODE           (0lu)
#define PRSm_TC_STOP_SIGNAL_MODE            (0lu)
#define PRSm_TC_CAPTURE_SIGNAL_MODE         (0lu)

/* Signal present */
#define PRSm_TC_RELOAD_SIGNAL_PRESENT       (0lu)
#define PRSm_TC_COUNT_SIGNAL_PRESENT        (0lu)
#define PRSm_TC_START_SIGNAL_PRESENT        (0lu)
#define PRSm_TC_STOP_SIGNAL_PRESENT         (0lu)
#define PRSm_TC_CAPTURE_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define PRSm_TC_INTERRUPT_MASK              (1lu)

/* PWM Mode */
/* Parameters */
#define PRSm_PWM_KILL_EVENT                 (0lu)
#define PRSm_PWM_STOP_EVENT                 (0lu)
#define PRSm_PWM_MODE                       (6lu)
#define PRSm_PWM_OUT_N_INVERT               (0lu)
#define PRSm_PWM_OUT_INVERT                 (1lu)
#define PRSm_PWM_ALIGN                      (0lu)
#define PRSm_PWM_RUN_MODE                   (0lu)
#define PRSm_PWM_DEAD_TIME_CYCLE            (0lu)
#define PRSm_PWM_PRESCALER                  (0lu)

/* Signal modes */
#define PRSm_PWM_RELOAD_SIGNAL_MODE         (0lu)
#define PRSm_PWM_COUNT_SIGNAL_MODE          (3lu)
#define PRSm_PWM_START_SIGNAL_MODE          (0lu)
#define PRSm_PWM_STOP_SIGNAL_MODE           (0lu)
#define PRSm_PWM_SWITCH_SIGNAL_MODE         (0lu)

/* Signal present */
#define PRSm_PWM_RELOAD_SIGNAL_PRESENT      (0lu)
#define PRSm_PWM_COUNT_SIGNAL_PRESENT       (0lu)
#define PRSm_PWM_START_SIGNAL_PRESENT       (0lu)
#define PRSm_PWM_STOP_SIGNAL_PRESENT        (0lu)
#define PRSm_PWM_SWITCH_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define PRSm_PWM_INTERRUPT_MASK             (0lu)


/***************************************
*    Initial Parameter Constants
***************************************/

/* Timer/Counter Mode */
#define PRSm_TC_PERIOD_VALUE                (65535lu)
#define PRSm_TC_COMPARE_VALUE               (65535lu)
#define PRSm_TC_COMPARE_BUF_VALUE           (65535lu)
#define PRSm_TC_COMPARE_SWAP                (0lu)

/* PWM Mode */
#define PRSm_PWM_PERIOD_VALUE               (32767lu)
#define PRSm_PWM_PERIOD_BUF_VALUE           (65535lu)
#define PRSm_PWM_PERIOD_SWAP                (0lu)
#define PRSm_PWM_COMPARE_VALUE              (1lu)
#define PRSm_PWM_COMPARE_BUF_VALUE          (65535lu)
#define PRSm_PWM_COMPARE_SWAP               (0lu)


/***************************************
*    Enumerated Types and Parameters
***************************************/

#define PRSm__LEFT 0
#define PRSm__RIGHT 1
#define PRSm__CENTER 2
#define PRSm__ASYMMETRIC 3

#define PRSm__X1 0
#define PRSm__X2 1
#define PRSm__X4 2

#define PRSm__PWM 4
#define PRSm__PWM_DT 5
#define PRSm__PWM_PR 6

#define PRSm__INVERSE 1
#define PRSm__DIRECT 0

#define PRSm__CAPTURE 2
#define PRSm__COMPARE 0

#define PRSm__TRIG_LEVEL 3
#define PRSm__TRIG_RISING 0
#define PRSm__TRIG_FALLING 1
#define PRSm__TRIG_BOTH 2

#define PRSm__INTR_MASK_TC 1
#define PRSm__INTR_MASK_CC_MATCH 2
#define PRSm__INTR_MASK_NONE 0
#define PRSm__INTR_MASK_TC_CC 3

#define PRSm__UNCONFIG 8
#define PRSm__TIMER 1
#define PRSm__QUAD 3
#define PRSm__PWM_SEL 7

#define PRSm__COUNT_UP 0
#define PRSm__COUNT_DOWN 1
#define PRSm__COUNT_UPDOWN0 2
#define PRSm__COUNT_UPDOWN1 3


/* Prescaler */
#define PRSm_PRESCALE_DIVBY1                ((uint32)(0u << PRSm_PRESCALER_SHIFT))
#define PRSm_PRESCALE_DIVBY2                ((uint32)(1u << PRSm_PRESCALER_SHIFT))
#define PRSm_PRESCALE_DIVBY4                ((uint32)(2u << PRSm_PRESCALER_SHIFT))
#define PRSm_PRESCALE_DIVBY8                ((uint32)(3u << PRSm_PRESCALER_SHIFT))
#define PRSm_PRESCALE_DIVBY16               ((uint32)(4u << PRSm_PRESCALER_SHIFT))
#define PRSm_PRESCALE_DIVBY32               ((uint32)(5u << PRSm_PRESCALER_SHIFT))
#define PRSm_PRESCALE_DIVBY64               ((uint32)(6u << PRSm_PRESCALER_SHIFT))
#define PRSm_PRESCALE_DIVBY128              ((uint32)(7u << PRSm_PRESCALER_SHIFT))

/* TCPWM set modes */
#define PRSm_MODE_TIMER_COMPARE             ((uint32)(PRSm__COMPARE         <<  \
                                                                  PRSm_MODE_SHIFT))
#define PRSm_MODE_TIMER_CAPTURE             ((uint32)(PRSm__CAPTURE         <<  \
                                                                  PRSm_MODE_SHIFT))
#define PRSm_MODE_QUAD                      ((uint32)(PRSm__QUAD            <<  \
                                                                  PRSm_MODE_SHIFT))
#define PRSm_MODE_PWM                       ((uint32)(PRSm__PWM             <<  \
                                                                  PRSm_MODE_SHIFT))
#define PRSm_MODE_PWM_DT                    ((uint32)(PRSm__PWM_DT          <<  \
                                                                  PRSm_MODE_SHIFT))
#define PRSm_MODE_PWM_PR                    ((uint32)(PRSm__PWM_PR          <<  \
                                                                  PRSm_MODE_SHIFT))

/* Quad Modes */
#define PRSm_MODE_X1                        ((uint32)(PRSm__X1              <<  \
                                                                  PRSm_QUAD_MODE_SHIFT))
#define PRSm_MODE_X2                        ((uint32)(PRSm__X2              <<  \
                                                                  PRSm_QUAD_MODE_SHIFT))
#define PRSm_MODE_X4                        ((uint32)(PRSm__X4              <<  \
                                                                  PRSm_QUAD_MODE_SHIFT))

/* Counter modes */
#define PRSm_COUNT_UP                       ((uint32)(PRSm__COUNT_UP        <<  \
                                                                  PRSm_UPDOWN_SHIFT))
#define PRSm_COUNT_DOWN                     ((uint32)(PRSm__COUNT_DOWN      <<  \
                                                                  PRSm_UPDOWN_SHIFT))
#define PRSm_COUNT_UPDOWN0                  ((uint32)(PRSm__COUNT_UPDOWN0   <<  \
                                                                  PRSm_UPDOWN_SHIFT))
#define PRSm_COUNT_UPDOWN1                  ((uint32)(PRSm__COUNT_UPDOWN1   <<  \
                                                                  PRSm_UPDOWN_SHIFT))

/* PWM output invert */
#define PRSm_INVERT_LINE                    ((uint32)(PRSm__INVERSE         <<  \
                                                                  PRSm_INV_OUT_SHIFT))
#define PRSm_INVERT_LINE_N                  ((uint32)(PRSm__INVERSE         <<  \
                                                                  PRSm_INV_COMPL_OUT_SHIFT))

/* Trigger modes */
#define PRSm_TRIG_RISING                    ((uint32)PRSm__TRIG_RISING)
#define PRSm_TRIG_FALLING                   ((uint32)PRSm__TRIG_FALLING)
#define PRSm_TRIG_BOTH                      ((uint32)PRSm__TRIG_BOTH)
#define PRSm_TRIG_LEVEL                     ((uint32)PRSm__TRIG_LEVEL)

/* Interrupt mask */
#define PRSm_INTR_MASK_TC                   ((uint32)PRSm__INTR_MASK_TC)
#define PRSm_INTR_MASK_CC_MATCH             ((uint32)PRSm__INTR_MASK_CC_MATCH)

/* PWM Output Controls */
#define PRSm_CC_MATCH_SET                   (0x00u)
#define PRSm_CC_MATCH_CLEAR                 (0x01u)
#define PRSm_CC_MATCH_INVERT                (0x02u)
#define PRSm_CC_MATCH_NO_CHANGE             (0x03u)
#define PRSm_OVERLOW_SET                    (0x00u)
#define PRSm_OVERLOW_CLEAR                  (0x04u)
#define PRSm_OVERLOW_INVERT                 (0x08u)
#define PRSm_OVERLOW_NO_CHANGE              (0x0Cu)
#define PRSm_UNDERFLOW_SET                  (0x00u)
#define PRSm_UNDERFLOW_CLEAR                (0x10u)
#define PRSm_UNDERFLOW_INVERT               (0x20u)
#define PRSm_UNDERFLOW_NO_CHANGE            (0x30u)

/* PWM Align */
#define PRSm_PWM_MODE_LEFT                  (PRSm_CC_MATCH_CLEAR        |   \
                                                         PRSm_OVERLOW_SET           |   \
                                                         PRSm_UNDERFLOW_NO_CHANGE)
#define PRSm_PWM_MODE_RIGHT                 (PRSm_CC_MATCH_SET          |   \
                                                         PRSm_OVERLOW_NO_CHANGE     |   \
                                                         PRSm_UNDERFLOW_CLEAR)
#define PRSm_PWM_MODE_ASYM                  (PRSm_CC_MATCH_INVERT       |   \
                                                         PRSm_OVERLOW_SET           |   \
                                                         PRSm_UNDERFLOW_CLEAR)

#if (PRSm_CY_TCPWM_V2)
    #if(PRSm_CY_TCPWM_4000)
        #define PRSm_PWM_MODE_CENTER                (PRSm_CC_MATCH_INVERT       |   \
                                                                 PRSm_OVERLOW_NO_CHANGE     |   \
                                                                 PRSm_UNDERFLOW_CLEAR)
    #else
        #define PRSm_PWM_MODE_CENTER                (PRSm_CC_MATCH_INVERT       |   \
                                                                 PRSm_OVERLOW_SET           |   \
                                                                 PRSm_UNDERFLOW_CLEAR)
    #endif /* (PRSm_CY_TCPWM_4000) */
#else
    #define PRSm_PWM_MODE_CENTER                (PRSm_CC_MATCH_INVERT       |   \
                                                             PRSm_OVERLOW_NO_CHANGE     |   \
                                                             PRSm_UNDERFLOW_CLEAR)
#endif /* (PRSm_CY_TCPWM_NEW) */

/* Command operations without condition */
#define PRSm_CMD_CAPTURE                    (0u)
#define PRSm_CMD_RELOAD                     (8u)
#define PRSm_CMD_STOP                       (16u)
#define PRSm_CMD_START                      (24u)

/* Status */
#define PRSm_STATUS_DOWN                    (1u)
#define PRSm_STATUS_RUNNING                 (2u)


/***************************************
*        Function Prototypes
****************************************/

void   PRSm_Init(void);
void   PRSm_Enable(void);
void   PRSm_Start(void);
void   PRSm_Stop(void);

void   PRSm_SetMode(uint32 mode);
void   PRSm_SetCounterMode(uint32 counterMode);
void   PRSm_SetPWMMode(uint32 modeMask);
void   PRSm_SetQDMode(uint32 qdMode);

void   PRSm_SetPrescaler(uint32 prescaler);
void   PRSm_TriggerCommand(uint32 mask, uint32 command);
void   PRSm_SetOneShot(uint32 oneShotEnable);
uint32 PRSm_ReadStatus(void);

void   PRSm_SetPWMSyncKill(uint32 syncKillEnable);
void   PRSm_SetPWMStopOnKill(uint32 stopOnKillEnable);
void   PRSm_SetPWMDeadTime(uint32 deadTime);
void   PRSm_SetPWMInvert(uint32 mask);

void   PRSm_SetInterruptMode(uint32 interruptMask);
uint32 PRSm_GetInterruptSourceMasked(void);
uint32 PRSm_GetInterruptSource(void);
void   PRSm_ClearInterrupt(uint32 interruptMask);
void   PRSm_SetInterrupt(uint32 interruptMask);

void   PRSm_WriteCounter(uint32 count);
uint32 PRSm_ReadCounter(void);

uint32 PRSm_ReadCapture(void);
uint32 PRSm_ReadCaptureBuf(void);

void   PRSm_WritePeriod(uint32 period);
uint32 PRSm_ReadPeriod(void);
void   PRSm_WritePeriodBuf(uint32 periodBuf);
uint32 PRSm_ReadPeriodBuf(void);

void   PRSm_WriteCompare(uint32 compare);
uint32 PRSm_ReadCompare(void);
void   PRSm_WriteCompareBuf(uint32 compareBuf);
uint32 PRSm_ReadCompareBuf(void);

void   PRSm_SetPeriodSwap(uint32 swapEnable);
void   PRSm_SetCompareSwap(uint32 swapEnable);

void   PRSm_SetCaptureMode(uint32 triggerMode);
void   PRSm_SetReloadMode(uint32 triggerMode);
void   PRSm_SetStartMode(uint32 triggerMode);
void   PRSm_SetStopMode(uint32 triggerMode);
void   PRSm_SetCountMode(uint32 triggerMode);

void   PRSm_SaveConfig(void);
void   PRSm_RestoreConfig(void);
void   PRSm_Sleep(void);
void   PRSm_Wakeup(void);


/***************************************
*             Registers
***************************************/

#define PRSm_BLOCK_CONTROL_REG              (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define PRSm_BLOCK_CONTROL_PTR              ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define PRSm_COMMAND_REG                    (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define PRSm_COMMAND_PTR                    ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define PRSm_INTRRUPT_CAUSE_REG             (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define PRSm_INTRRUPT_CAUSE_PTR             ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define PRSm_CONTROL_REG                    (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__CTRL )
#define PRSm_CONTROL_PTR                    ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__CTRL )
#define PRSm_STATUS_REG                     (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__STATUS )
#define PRSm_STATUS_PTR                     ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__STATUS )
#define PRSm_COUNTER_REG                    (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__COUNTER )
#define PRSm_COUNTER_PTR                    ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__COUNTER )
#define PRSm_COMP_CAP_REG                   (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__CC )
#define PRSm_COMP_CAP_PTR                   ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__CC )
#define PRSm_COMP_CAP_BUF_REG               (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__CC_BUFF )
#define PRSm_COMP_CAP_BUF_PTR               ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__CC_BUFF )
#define PRSm_PERIOD_REG                     (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__PERIOD )
#define PRSm_PERIOD_PTR                     ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__PERIOD )
#define PRSm_PERIOD_BUF_REG                 (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define PRSm_PERIOD_BUF_PTR                 ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define PRSm_TRIG_CONTROL0_REG              (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define PRSm_TRIG_CONTROL0_PTR              ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define PRSm_TRIG_CONTROL1_REG              (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define PRSm_TRIG_CONTROL1_PTR              ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define PRSm_TRIG_CONTROL2_REG              (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define PRSm_TRIG_CONTROL2_PTR              ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define PRSm_INTERRUPT_REQ_REG              (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__INTR )
#define PRSm_INTERRUPT_REQ_PTR              ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__INTR )
#define PRSm_INTERRUPT_SET_REG              (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__INTR_SET )
#define PRSm_INTERRUPT_SET_PTR              ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__INTR_SET )
#define PRSm_INTERRUPT_MASK_REG             (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__INTR_MASK )
#define PRSm_INTERRUPT_MASK_PTR             ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__INTR_MASK )
#define PRSm_INTERRUPT_MASKED_REG           (*(reg32 *) PRSm_cy_m0s8_tcpwm_1__INTR_MASKED )
#define PRSm_INTERRUPT_MASKED_PTR           ( (reg32 *) PRSm_cy_m0s8_tcpwm_1__INTR_MASKED )


/***************************************
*       Registers Constants
***************************************/

/* Mask */
#define PRSm_MASK                           ((uint32)PRSm_cy_m0s8_tcpwm_1__TCPWM_CTRL_MASK)

/* Shift constants for control register */
#define PRSm_RELOAD_CC_SHIFT                (0u)
#define PRSm_RELOAD_PERIOD_SHIFT            (1u)
#define PRSm_PWM_SYNC_KILL_SHIFT            (2u)
#define PRSm_PWM_STOP_KILL_SHIFT            (3u)
#define PRSm_PRESCALER_SHIFT                (8u)
#define PRSm_UPDOWN_SHIFT                   (16u)
#define PRSm_ONESHOT_SHIFT                  (18u)
#define PRSm_QUAD_MODE_SHIFT                (20u)
#define PRSm_INV_OUT_SHIFT                  (20u)
#define PRSm_INV_COMPL_OUT_SHIFT            (21u)
#define PRSm_MODE_SHIFT                     (24u)

/* Mask constants for control register */
#define PRSm_RELOAD_CC_MASK                 ((uint32)(PRSm_1BIT_MASK        <<  \
                                                                            PRSm_RELOAD_CC_SHIFT))
#define PRSm_RELOAD_PERIOD_MASK             ((uint32)(PRSm_1BIT_MASK        <<  \
                                                                            PRSm_RELOAD_PERIOD_SHIFT))
#define PRSm_PWM_SYNC_KILL_MASK             ((uint32)(PRSm_1BIT_MASK        <<  \
                                                                            PRSm_PWM_SYNC_KILL_SHIFT))
#define PRSm_PWM_STOP_KILL_MASK             ((uint32)(PRSm_1BIT_MASK        <<  \
                                                                            PRSm_PWM_STOP_KILL_SHIFT))
#define PRSm_PRESCALER_MASK                 ((uint32)(PRSm_8BIT_MASK        <<  \
                                                                            PRSm_PRESCALER_SHIFT))
#define PRSm_UPDOWN_MASK                    ((uint32)(PRSm_2BIT_MASK        <<  \
                                                                            PRSm_UPDOWN_SHIFT))
#define PRSm_ONESHOT_MASK                   ((uint32)(PRSm_1BIT_MASK        <<  \
                                                                            PRSm_ONESHOT_SHIFT))
#define PRSm_QUAD_MODE_MASK                 ((uint32)(PRSm_3BIT_MASK        <<  \
                                                                            PRSm_QUAD_MODE_SHIFT))
#define PRSm_INV_OUT_MASK                   ((uint32)(PRSm_2BIT_MASK        <<  \
                                                                            PRSm_INV_OUT_SHIFT))
#define PRSm_MODE_MASK                      ((uint32)(PRSm_3BIT_MASK        <<  \
                                                                            PRSm_MODE_SHIFT))

/* Shift constants for trigger control register 1 */
#define PRSm_CAPTURE_SHIFT                  (0u)
#define PRSm_COUNT_SHIFT                    (2u)
#define PRSm_RELOAD_SHIFT                   (4u)
#define PRSm_STOP_SHIFT                     (6u)
#define PRSm_START_SHIFT                    (8u)

/* Mask constants for trigger control register 1 */
#define PRSm_CAPTURE_MASK                   ((uint32)(PRSm_2BIT_MASK        <<  \
                                                                  PRSm_CAPTURE_SHIFT))
#define PRSm_COUNT_MASK                     ((uint32)(PRSm_2BIT_MASK        <<  \
                                                                  PRSm_COUNT_SHIFT))
#define PRSm_RELOAD_MASK                    ((uint32)(PRSm_2BIT_MASK        <<  \
                                                                  PRSm_RELOAD_SHIFT))
#define PRSm_STOP_MASK                      ((uint32)(PRSm_2BIT_MASK        <<  \
                                                                  PRSm_STOP_SHIFT))
#define PRSm_START_MASK                     ((uint32)(PRSm_2BIT_MASK        <<  \
                                                                  PRSm_START_SHIFT))

/* MASK */
#define PRSm_1BIT_MASK                      ((uint32)0x01u)
#define PRSm_2BIT_MASK                      ((uint32)0x03u)
#define PRSm_3BIT_MASK                      ((uint32)0x07u)
#define PRSm_6BIT_MASK                      ((uint32)0x3Fu)
#define PRSm_8BIT_MASK                      ((uint32)0xFFu)
#define PRSm_16BIT_MASK                     ((uint32)0xFFFFu)

/* Shift constant for status register */
#define PRSm_RUNNING_STATUS_SHIFT           (30u)


/***************************************
*    Initial Constants
***************************************/

#define PRSm_CTRL_QUAD_BASE_CONFIG                                                          \
        (((uint32)(PRSm_QUAD_ENCODING_MODES     << PRSm_QUAD_MODE_SHIFT))       |\
         ((uint32)(PRSm_CONFIG                  << PRSm_MODE_SHIFT)))

#define PRSm_CTRL_PWM_BASE_CONFIG                                                           \
        (((uint32)(PRSm_PWM_STOP_EVENT          << PRSm_PWM_STOP_KILL_SHIFT))   |\
         ((uint32)(PRSm_PWM_OUT_INVERT          << PRSm_INV_OUT_SHIFT))         |\
         ((uint32)(PRSm_PWM_OUT_N_INVERT        << PRSm_INV_COMPL_OUT_SHIFT))   |\
         ((uint32)(PRSm_PWM_MODE                << PRSm_MODE_SHIFT)))

#define PRSm_CTRL_PWM_RUN_MODE                                                              \
            ((uint32)(PRSm_PWM_RUN_MODE         << PRSm_ONESHOT_SHIFT))
            
#define PRSm_CTRL_PWM_ALIGN                                                                 \
            ((uint32)(PRSm_PWM_ALIGN            << PRSm_UPDOWN_SHIFT))

#define PRSm_CTRL_PWM_KILL_EVENT                                                            \
             ((uint32)(PRSm_PWM_KILL_EVENT      << PRSm_PWM_SYNC_KILL_SHIFT))

#define PRSm_CTRL_PWM_DEAD_TIME_CYCLE                                                       \
            ((uint32)(PRSm_PWM_DEAD_TIME_CYCLE  << PRSm_PRESCALER_SHIFT))

#define PRSm_CTRL_PWM_PRESCALER                                                             \
            ((uint32)(PRSm_PWM_PRESCALER        << PRSm_PRESCALER_SHIFT))

#define PRSm_CTRL_TIMER_BASE_CONFIG                                                         \
        (((uint32)(PRSm_TC_PRESCALER            << PRSm_PRESCALER_SHIFT))       |\
         ((uint32)(PRSm_TC_COUNTER_MODE         << PRSm_UPDOWN_SHIFT))          |\
         ((uint32)(PRSm_TC_RUN_MODE             << PRSm_ONESHOT_SHIFT))         |\
         ((uint32)(PRSm_TC_COMP_CAP_MODE        << PRSm_MODE_SHIFT)))
        
#define PRSm_QUAD_SIGNALS_MODES                                                             \
        (((uint32)(PRSm_QUAD_PHIA_SIGNAL_MODE   << PRSm_COUNT_SHIFT))           |\
         ((uint32)(PRSm_QUAD_INDEX_SIGNAL_MODE  << PRSm_RELOAD_SHIFT))          |\
         ((uint32)(PRSm_QUAD_STOP_SIGNAL_MODE   << PRSm_STOP_SHIFT))            |\
         ((uint32)(PRSm_QUAD_PHIB_SIGNAL_MODE   << PRSm_START_SHIFT)))

#define PRSm_PWM_SIGNALS_MODES                                                              \
        (((uint32)(PRSm_PWM_SWITCH_SIGNAL_MODE  << PRSm_CAPTURE_SHIFT))         |\
         ((uint32)(PRSm_PWM_COUNT_SIGNAL_MODE   << PRSm_COUNT_SHIFT))           |\
         ((uint32)(PRSm_PWM_RELOAD_SIGNAL_MODE  << PRSm_RELOAD_SHIFT))          |\
         ((uint32)(PRSm_PWM_STOP_SIGNAL_MODE    << PRSm_STOP_SHIFT))            |\
         ((uint32)(PRSm_PWM_START_SIGNAL_MODE   << PRSm_START_SHIFT)))

#define PRSm_TIMER_SIGNALS_MODES                                                            \
        (((uint32)(PRSm_TC_CAPTURE_SIGNAL_MODE  << PRSm_CAPTURE_SHIFT))         |\
         ((uint32)(PRSm_TC_COUNT_SIGNAL_MODE    << PRSm_COUNT_SHIFT))           |\
         ((uint32)(PRSm_TC_RELOAD_SIGNAL_MODE   << PRSm_RELOAD_SHIFT))          |\
         ((uint32)(PRSm_TC_STOP_SIGNAL_MODE     << PRSm_STOP_SHIFT))            |\
         ((uint32)(PRSm_TC_START_SIGNAL_MODE    << PRSm_START_SHIFT)))
        
#define PRSm_TIMER_UPDOWN_CNT_USED                                                          \
                ((PRSm__COUNT_UPDOWN0 == PRSm_TC_COUNTER_MODE)                  ||\
                 (PRSm__COUNT_UPDOWN1 == PRSm_TC_COUNTER_MODE))

#define PRSm_PWM_UPDOWN_CNT_USED                                                            \
                ((PRSm__CENTER == PRSm_PWM_ALIGN)                               ||\
                 (PRSm__ASYMMETRIC == PRSm_PWM_ALIGN))               
        
#define PRSm_PWM_PR_INIT_VALUE              (1u)
#define PRSm_QUAD_PERIOD_INIT_VALUE         (0x8000u)



#endif /* End CY_TCPWM_PRSm_H */

/* [] END OF FILE */
